#Print monthly expenditure
#Practical 6, Part 2 (a)
#author your name
                                                                 
#define variables and assign values to them
foodExpenses = 300.0 #variable for food expenses
leisureExpenses = 100.0 #assign 100.0 to leisureExpenses
clothesExpenses = 50.0  #assign 50.0 to clothesExpenses
totalSpent = 0.0  # variable for total expenses, initialised to 0.0

totalSpent = foodExpenses + leisureExpenses + clothesExpenses

print("The total expenditure this month was: ", totalSpent)

